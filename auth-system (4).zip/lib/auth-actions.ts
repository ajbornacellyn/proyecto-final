"use server"
import { sanitizeInput } from "@/lib/security-utils"
import { logSecurityEvent } from "@/lib/audit-logger"
import { sendEmail } from "@/lib/email-service"

// Simulated database of users
const users = new Map()

// Simulated verification codes storage
const verificationCodes = new Map()

// Simulated rate limiting
const loginAttempts = new Map()
const MAX_LOGIN_ATTEMPTS = 5
const RATE_LIMIT_RESET_TIME = 15 * 60 * 1000 // 15 minutes

export async function loginUser(email: string, password: string) {
  // Sanitize inputs
  const sanitizedEmail = sanitizeInput(email.toLowerCase())

  // Check rate limiting
  const userAttempts = loginAttempts.get(sanitizedEmail) || { count: 0, timestamp: Date.now() }

  // Reset attempts if time has passed
  if (Date.now() - userAttempts.timestamp > RATE_LIMIT_RESET_TIME) {
    userAttempts.count = 0
    userAttempts.timestamp = Date.now()
  }

  // Check if user is rate limited
  if (userAttempts.count >= MAX_LOGIN_ATTEMPTS) {
    logSecurityEvent({
      type: "RATE_LIMIT_EXCEEDED",
      user: sanitizedEmail,
      details: "Too many login attempts",
      ip: "127.0.0.1", // In a real app, this would be the actual IP
    })

    return {
      success: false,
      error: "Too many login attempts. Please try again later.",
    }
  }

  // Simulate authentication
  const user = users.get(sanitizedEmail)

  if (!user) {
    // Increment failed attempts
    userAttempts.count++
    loginAttempts.set(sanitizedEmail, userAttempts)

    logSecurityEvent({
      type: "FAILED_LOGIN",
      user: sanitizedEmail,
      details: "User not found",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Invalid email or password",
    }
  }

  // In a real app, you would use a proper password hashing library
  // like bcrypt to compare the password
  if (user.password !== password) {
    // Increment failed attempts
    userAttempts.count++
    loginAttempts.set(sanitizedEmail, userAttempts)

    logSecurityEvent({
      type: "FAILED_LOGIN",
      user: sanitizedEmail,
      details: "Invalid password",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Invalid email or password",
    }
  }

  // Reset login attempts on successful login
  loginAttempts.delete(sanitizedEmail)

  logSecurityEvent({
    type: "SUCCESSFUL_LOGIN",
    user: sanitizedEmail,
    details: "User logged in successfully",
    ip: "127.0.0.1",
  })

  return {
    success: true,
    user: {
      email: user.email,
      name: user.name,
    },
  }
}

export async function registerUser(name: string, email: string, password: string) {
  // Sanitize inputs
  const sanitizedName = sanitizeInput(name)
  const sanitizedEmail = sanitizeInput(email.toLowerCase())

  // Check if user already exists
  if (users.has(sanitizedEmail)) {
    logSecurityEvent({
      type: "FAILED_REGISTRATION",
      user: sanitizedEmail,
      details: "Email already in use",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Email already in use",
    }
  }

  // In a real app, you would hash the password before storing it
  users.set(sanitizedEmail, {
    name: sanitizedName,
    email: sanitizedEmail,
    password: password, // This would be hashed in a real app
    createdAt: new Date(),
  })

  logSecurityEvent({
    type: "USER_REGISTERED",
    user: sanitizedEmail,
    details: "New user registered",
    ip: "127.0.0.1",
  })

  return {
    success: true,
  }
}

export async function sendVerificationCode(email: string) {
  // Sanitize input
  const sanitizedEmail = sanitizeInput(email.toLowerCase())

  // Generate a random 6-digit code
  const code = Math.floor(100000 + Math.random() * 900000).toString()

  // Store the code with an expiration time (15 minutes)
  verificationCodes.set(sanitizedEmail, {
    code,
    expiresAt: Date.now() + 15 * 60 * 1000,
  })

  // In a real app, send the code via email
  try {
    // This is a simulated email sending function
    await sendEmail({
      to: sanitizedEmail,
      subject: "Your Verification Code",
      body: `Your verification code is: ${code}. It will expire in 15 minutes.`,
    })

    logSecurityEvent({
      type: "2FA_CODE_SENT",
      user: sanitizedEmail,
      details: "Verification code sent to user's email",
      ip: "127.0.0.1",
    })

    return {
      success: true,
    }
  } catch (error) {
    logSecurityEvent({
      type: "2FA_CODE_SEND_FAILED",
      user: sanitizedEmail,
      details: "Failed to send verification code",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Failed to send verification code. Please try again.",
    }
  }
}

export async function verifyTwoFactorCode(email: string, code: string) {
  // Sanitize inputs
  const sanitizedEmail = sanitizeInput(email.toLowerCase())

  // Get the stored verification data
  const verificationData = verificationCodes.get(sanitizedEmail)

  if (!verificationData) {
    logSecurityEvent({
      type: "2FA_FAILED",
      user: sanitizedEmail,
      details: "No verification code found",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Verification code not found or expired. Please request a new code.",
    }
  }

  // Check if the code has expired
  if (Date.now() > verificationData.expiresAt) {
    // Remove expired code
    verificationCodes.delete(sanitizedEmail)

    logSecurityEvent({
      type: "2FA_FAILED",
      user: sanitizedEmail,
      details: "Verification code expired",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Verification code has expired. Please request a new code.",
    }
  }

  // Check if the code matches
  if (verificationData.code !== code) {
    logSecurityEvent({
      type: "2FA_FAILED",
      user: sanitizedEmail,
      details: "Invalid verification code",
      ip: "127.0.0.1",
    })

    return {
      success: false,
      error: "Invalid verification code. Please try again.",
    }
  }

  // Code is valid, remove it to prevent reuse
  verificationCodes.delete(sanitizedEmail)

  logSecurityEvent({
    type: "2FA_SUCCESS",
    user: sanitizedEmail,
    details: "Two-factor authentication successful",
    ip: "127.0.0.1",
  })

  return {
    success: true,
  }
}

