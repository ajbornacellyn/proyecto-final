/**
 * Audit logging functionality for security events
 */

interface SecurityEvent {
  type: string
  user: string
  details: string
  ip: string
  timestamp?: Date
}

// In-memory log storage (in a real app, this would write to a database or external logging service)
const securityLogs: SecurityEvent[] = []

export function logSecurityEvent(event: SecurityEvent) {
  const logEntry = {
    ...event,
    timestamp: new Date(),
  }

  // Add to in-memory logs
  securityLogs.push(logEntry)

  // In a real app, you would send this to a secure logging service
  console.log(
    `[SECURITY_AUDIT] ${logEntry.timestamp.toISOString()} | ${logEntry.type} | User: ${logEntry.user} | ${logEntry.details} | IP: ${logEntry.ip}`,
  )

  // For critical events, you might want to trigger alerts
  if (
    event.type === "BRUTE_FORCE_ATTEMPT" ||
    event.type === "RATE_LIMIT_EXCEEDED" ||
    event.type === "SUSPICIOUS_ACTIVITY"
  ) {
    // In a real app, this would trigger an alert to security team
    console.warn(`[SECURITY_ALERT] Potential security threat detected: ${event.type} for user ${event.user}`)
  }

  return logEntry
}

export function getSecurityLogs(user?: string): SecurityEvent[] {
  if (user) {
    return securityLogs.filter((log) => log.user === user)
  }
  return securityLogs
}

